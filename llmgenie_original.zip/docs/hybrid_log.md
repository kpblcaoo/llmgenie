2025-06-07 00:39:41,523 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-07 00:39:57,956 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-07 00:42:15,776 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-07 00:42:15,782 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-07 00:42:17,753 - INFO - Generated ./struct.json
2025-06-07 00:42:17,764 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llm/llmgenie/.llmstruct_index
2025-06-07 02:02:52,733 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-07 02:04:50,534 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-07 02:07:15,184 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-07 02:07:23,453 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-07 02:07:39,225 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-07 02:07:51,009 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-07 02:08:02,898 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-08 07:58:07,835 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-08 07:58:07,850 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-08 07:58:10,079 - INFO - Generated ./struct.json
2025-06-08 07:58:10,094 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llm/llmgenie/.llmstruct_index
2025-06-09 02:46:52,182 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-09 02:47:26,577 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-09 02:47:57,388 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-09 02:47:57,393 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-09 02:47:57,474 - INFO - Generated ./struct.json
2025-06-09 02:47:57,484 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llm/llmgenie/src/.llmstruct_index
2025-06-09 02:58:37,911 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-09 03:16:05,544 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-09 03:16:05,560 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-09 03:16:05,776 - INFO - Generated ./struct.json
2025-06-09 03:16:05,796 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llm/llmgenie/src/.llmstruct_index
2025-06-09 09:29:31,793 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-09 09:29:31,806 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-09 09:29:31,928 - INFO - Generated ./struct.json
2025-06-09 09:29:31,943 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llm/llmgenie/src/.llmstruct_index
2025-06-09 16:39:17,217 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-09 16:40:15,825 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-09 16:40:15,831 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-09 16:40:15,931 - INFO - Generated ./src/struct.json
2025-06-09 16:40:15,941 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llmgenie/src/.llmstruct_index
2025-06-09 16:41:52,613 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-09 16:41:52,619 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-09 16:41:52,636 - INFO - Generated ./tests/struct.json
2025-06-09 16:41:52,638 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llmgenie/tests/.llmstruct_index
2025-06-09 16:55:27,386 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-09 16:55:27,392 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-09 16:55:27,521 - INFO - Generated ./src/struct.json
2025-06-09 16:55:27,533 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llmgenie/src/.llmstruct_index
2025-06-09 17:01:17,172 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-09 17:01:17,181 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-09 17:01:17,346 - INFO - Generated ./src/struct.json
2025-06-09 17:01:17,365 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llmgenie/src/.llmstruct_index
2025-06-09 17:25:44,901 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-09 17:25:44,907 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-09 17:25:45,036 - INFO - Generated ./src/struct.json
2025-06-09 17:25:45,049 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llmgenie/src/.llmstruct_index
2025-06-09 17:25:48,412 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-09 17:25:48,419 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-09 17:25:48,478 - INFO - Generated ./tests/struct.json
2025-06-09 17:25:48,482 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llmgenie/tests/.llmstruct_index
2025-06-09 17:34:13,561 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-09 17:34:13,567 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-09 17:34:13,593 - INFO - Generated ./tests/struct.json
2025-06-09 17:34:13,626 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llmgenie/tests/.llmstruct_index
2025-06-09 17:34:25,632 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-09 17:34:25,638 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-09 17:34:25,767 - INFO - Generated ./src/struct.json
2025-06-09 17:34:25,780 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llmgenie/src/.llmstruct_index
2025-06-09 17:39:26,950 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-09 17:39:26,956 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-09 17:39:27,079 - INFO - Generated ./src/struct.json
2025-06-09 17:39:27,092 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llmgenie/src/.llmstruct_index
2025-06-09 17:39:32,274 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-09 17:39:32,280 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-09 17:39:32,313 - INFO - Generated ./tests/struct.json
2025-06-09 17:39:32,348 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llmgenie/tests/.llmstruct_index
2025-06-09 18:01:43,797 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-09 18:01:43,804 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-09 18:01:43,860 - INFO - Generated ./tests/struct.json
2025-06-09 18:01:43,865 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llmgenie/tests/.llmstruct_index
2025-06-09 18:41:55,511 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-09 18:41:55,517 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-09 18:41:55,643 - INFO - Generated ./src/struct.json
2025-06-09 18:41:55,658 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llmgenie/src/.llmstruct_index
2025-06-09 19:14:06,615 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-09 19:14:06,621 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-09 19:14:06,761 - INFO - Generated ./src/struct.json
2025-06-09 19:14:06,779 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llmgenie/src/.llmstruct_index
2025-06-09 19:27:56,115 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-09 19:27:56,121 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-09 19:27:56,268 - INFO - Generated ./src/struct.json
2025-06-09 19:27:56,350 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llmgenie/src/.llmstruct_index
2025-06-09 20:23:39,059 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-09 20:23:39,065 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-09 20:23:39,201 - INFO - Generated ./src/struct.json
2025-06-09 20:23:39,216 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llmgenie/src/.llmstruct_index
2025-06-09 20:28:51,213 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-09 20:29:25,455 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-09 20:29:42,392 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-09 20:29:42,398 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-09 20:29:42,543 - INFO - Generated src/struct.json
2025-06-09 20:29:42,564 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llmgenie/src/.llmstruct_index
2025-06-09 23:50:58,315 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-09 23:50:58,321 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-09 23:50:58,464 - INFO - Generated ./src/struct.json
2025-06-09 23:50:58,478 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llmgenie/src/.llmstruct_index
2025-06-10 00:08:44,519 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-10 00:08:44,525 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-10 00:08:44,667 - INFO - Generated src/struct.json
2025-06-10 00:08:44,682 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llmgenie/src/.llmstruct_index
2025-06-10 00:34:29,077 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-10 00:34:29,084 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-10 00:34:29,228 - INFO - Generated src/struct.json
2025-06-10 00:34:29,243 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llmgenie/src/.llmstruct_index
2025-06-10 11:28:05,857 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-10 11:28:05,864 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-10 11:28:05,997 - INFO - Generated src/struct.json
2025-06-10 11:28:06,016 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llmgenie/src/.llmstruct_index
2025-06-10 15:31:35,351 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-10 15:31:35,357 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-10 15:31:35,575 - INFO - Generated src/struct.json
2025-06-10 15:31:35,595 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llmgenie/src/.llmstruct_index
2025-06-10 21:01:36,902 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-10 21:01:36,908 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-10 21:01:36,965 - INFO - Generated tests/struct.json
2025-06-10 21:01:36,970 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llmgenie/tests/.llmstruct_index
2025-06-10 22:13:31,272 - WARNING - Modular CLI components not available: No module named 'src.llmgenie.cli_core'
2025-06-10 22:13:38,740 - WARNING - Modular CLI components not available: No module named 'src.llmgenie.cli_core'
2025-06-10 22:13:43,582 - WARNING - Modular CLI components not available: No module named 'src.llmgenie.cli_core'
2025-06-10 22:13:43,589 - ERROR - Context file struct.json does not exist
2025-06-10 22:14:15,171 - INFO - Grok API key: xai-l8mM8EaycBsV2IRNkD2pPy3ZqxqVSOt4qYZqowpkbguWx3woXszK1s7ck6n66HtwPzjzcclxQmnUFcCF
2025-06-10 22:14:15,171 - INFO - Querying in grok mode with prompt: What is 2+2? Answer briefly.
2025-06-10 22:14:16,038 - INFO - Grok query successful
2025-06-10 22:16:25,642 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-10 22:16:25,648 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-10 22:16:25,717 - INFO - Generated tests/struct.json
2025-06-10 22:16:25,723 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llmgenie/tests/.llmstruct_index
2025-06-10 22:16:33,945 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-10 22:16:33,951 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-10 22:16:34,084 - INFO - Generated src/struct.json
2025-06-10 22:16:34,103 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llmgenie/src/.llmstruct_index
2025-06-10 22:24:08,429 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-10 22:24:08,435 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-10 22:24:08,587 - INFO - Generated src/struct.json
2025-06-10 22:24:08,609 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llmgenie/src/.llmstruct_index
2025-06-10 22:33:08,417 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-10 22:33:08,423 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-10 22:33:08,570 - INFO - Generated src/struct.json
2025-06-10 22:33:08,586 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llmgenie/src/.llmstruct_index
2025-06-10 23:45:45,389 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-10 23:45:45,396 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-10 23:45:45,563 - INFO - Generated src/struct.json
2025-06-10 23:45:45,579 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llmgenie/src/.llmstruct_index
2025-06-10 23:57:08,671 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-10 23:57:08,677 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-10 23:57:08,824 - INFO - Generated src/struct.json
2025-06-10 23:57:08,840 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llmgenie/src/.llmstruct_index
2025-06-10 23:59:37,729 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-10 23:59:37,736 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-10 23:59:37,897 - INFO - Generated src/struct.json
2025-06-10 23:59:37,914 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llmgenie/src/.llmstruct_index
2025-06-11 03:04:52,410 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-11 03:04:52,416 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-11 03:04:52,559 - INFO - Generated src/struct.json
2025-06-11 03:04:52,581 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llmgenie/src/.llmstruct_index
2025-06-11 09:16:50,177 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-11 09:16:50,183 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-11 09:16:50,342 - INFO - Generated src/struct.json
2025-06-11 09:16:50,367 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llmgenie/src/.llmstruct_index
2025-06-11 09:17:09,072 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-11 09:17:09,078 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-11 09:17:09,141 - INFO - Generated tests/struct.json
2025-06-11 09:17:09,147 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llmgenie/tests/.llmstruct_index
2025-06-11 09:32:07,341 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-11 09:32:07,347 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-11 09:32:07,535 - INFO - Generated src/struct.json
2025-06-11 09:32:07,557 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llmgenie/src/.llmstruct_index
2025-06-11 10:16:38,492 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-11 10:16:38,498 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-11 10:16:38,669 - INFO - Generated src/struct.json
2025-06-11 10:16:38,697 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llmgenie/src/.llmstruct_index
2025-06-11 11:28:20,186 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-11 11:28:20,192 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-11 11:28:20,379 - INFO - Generated src/struct.json
2025-06-11 11:28:20,402 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llmgenie/src/.llmstruct_index
2025-06-11 12:15:48,297 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-11 12:15:48,306 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-11 12:15:48,508 - INFO - Generated src/struct.json
2025-06-11 12:15:48,533 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llmgenie/src/.llmstruct_index
2025-06-11 12:30:32,677 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-11 12:30:32,685 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-11 12:30:32,890 - INFO - Generated src/struct.json
2025-06-11 12:30:32,915 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llmgenie/src/.llmstruct_index
2025-06-11 20:04:49,353 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-11 20:04:49,359 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-11 20:04:49,596 - INFO - Generated src/struct.json
2025-06-11 20:04:49,627 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llmgenie/src/.llmstruct_index
2025-06-11 23:18:56,084 - WARNING - Modular CLI components not available: No module named 'src.llmgenie.cli_core'
2025-06-12 13:31:02,331 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-12 13:31:02,336 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-12 13:31:02,588 - INFO - Generated src/struct.json
2025-06-12 13:31:02,626 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llmgenie/src/.llmstruct_index
2025-06-12 13:31:05,829 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-12 13:31:05,835 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-12 13:31:05,896 - INFO - Generated tests/struct.json
2025-06-12 13:31:05,903 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llmgenie/tests/.llmstruct_index
2025-06-12 14:36:17,639 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-12 14:36:17,645 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-12 14:36:18,512 - INFO - Generated ./struct.json
2025-06-12 14:36:18,578 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llmgenie/.llmstruct_index
2025-06-12 15:09:06,272 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-12 15:09:06,278 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-12 15:09:07,285 - INFO - Generated ./struct.json
2025-06-12 15:09:07,392 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llmgenie/.llmstruct_index
2025-06-12 15:09:29,802 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-12 15:09:29,808 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-12 15:09:30,770 - INFO - Generated ./struct.json
2025-06-12 15:09:30,855 - INFO - Модульный индекс сохранён в /home/kpblc/projects/llmgenie/.llmstruct_index
