2025-06-01 23:26:45,803 - WARNING - Modular CLI components not available: No module named 'llmstruct.cli_core'
2025-06-01 23:26:45,827 - WARNING - No project goals specified via --goals or llmstruct.toml. Consider adding goals for better context.
2025-06-01 23:26:46,352 - INFO - Generated ./src/struct.json
2025-06-01 23:26:46,405 - INFO - Модульный индекс сохранён в /home/sma/projects/llmstruct/llmstruct/src/.llmstruct_index
