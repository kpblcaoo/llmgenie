"""
llmgenie API module
FastAPI-based REST API for llmgenie orchestration
"""

__version__ = "0.1.0" 