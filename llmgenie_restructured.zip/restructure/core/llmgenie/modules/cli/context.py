import logging

def context(args):
    """Generate context.json from input JSON."""
    logging.warning("Context command not implemented yet (TSK-091)") 