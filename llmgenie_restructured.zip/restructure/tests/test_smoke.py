def test_smoke():
    assert 1 == 1
