# Architecture Report - Unknown

**Generated:** 2025-06-11 14:10:22  
**Based on:** None  

## Project Overview

- **Total Modules:** 54
- **Total Functions:** 272
- **Total Classes:** 58
- **Call Edges:** 0
- **Dependencies:** 0
- **Modular Index:** ✅ Available

## Top 10 Most Complex Modules

### 1. struct_tools/mcp_interface.py

- **Functions:** 16
- **Classes:** 6
- **Code Lines:** 0
- **Complexity Score:** 66.5
- **Avg Function Length:** 0.0 lines
- **Max Function Length:** 0 lines

### 2. llmgenie/task_router/model_router.py

- **Functions:** 14
- **Classes:** 3
- **Code Lines:** 0
- **Complexity Score:** 66.5
- **Avg Function Length:** 0.0 lines
- **Max Function Length:** 0 lines

### 3. llmgenie/orchestration/agent_orchestrator.py

- **Functions:** 14
- **Classes:** 5
- **Code Lines:** 0
- **Complexity Score:** 63.5
- **Avg Function Length:** 0.0 lines
- **Max Function Length:** 0 lines

### 4. llmgenie/task_router/quality_validator.py

- **Functions:** 14
- **Classes:** 3
- **Code Lines:** 0
- **Complexity Score:** 60.5
- **Avg Function Length:** 0.0 lines
- **Max Function Length:** 0 lines

### 5. struct_tools/structure_analyzer.py

- **Functions:** 14
- **Classes:** 2
- **Code Lines:** 0
- **Complexity Score:** 55.0
- **Avg Function Length:** 0.0 lines
- **Max Function Length:** 0 lines

### 6. llmgenie/mcp/tools.py

- **Functions:** 14
- **Classes:** 3
- **Code Lines:** 0
- **Complexity Score:** 55.0
- **Avg Function Length:** 0.0 lines
- **Max Function Length:** 0 lines

### 7. llmgenie/api/handoff_validator.py

- **Functions:** 9
- **Classes:** 6
- **Code Lines:** 0
- **Complexity Score:** 53.0
- **Avg Function Length:** 0.0 lines
- **Max Function Length:** 0 lines

### 8. llmgenie/task_router/quality_intelligence.py

- **Functions:** 9
- **Classes:** 4
- **Code Lines:** 0
- **Complexity Score:** 47.5
- **Avg Function Length:** 0.0 lines
- **Max Function Length:** 0 lines

### 9. rag_context/interfaces/http_api.py

- **Functions:** 15
- **Classes:** 6
- **Code Lines:** 0
- **Complexity Score:** 46.0
- **Avg Function Length:** 0.0 lines
- **Max Function Length:** 0 lines

### 10. llmgenie/task_router/task_classifier.py

- **Functions:** 8
- **Classes:** 4
- **Code Lines:** 0
- **Complexity Score:** 44.0
- **Avg Function Length:** 0.0 lines
- **Max Function Length:** 0 lines
